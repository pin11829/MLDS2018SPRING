python3 hw1-3-3-1.py
