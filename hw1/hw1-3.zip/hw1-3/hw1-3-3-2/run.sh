python3 train.py
python3 plot.py